# NOVARO CV

A simple Arabic/French CV builder that works in the browser.

## Run locally
Open `index.html` in a modern browser.

## Deploy
This is a static site. Upload the files to a public GitHub repository and connect that repository to Render as a Static Site.

## PDF
Use the “تحميل PDF” button, then choose “Save as PDF” in the browser print dialog.

## Privacy
The form data is processed locally in the browser and is not sent to a server.
