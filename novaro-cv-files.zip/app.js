const ids=["name","job","city","email","phone","summary","experience","experienceDetails","education","skills"];
const $=id=>document.getElementById(id);
const map={name:"outName",job:"outJob",summary:"outSummary",experience:"outExperience",experienceDetails:"outExperienceDetails",education:"outEducation"};
function update(){ids.forEach(id=>{let v=$(id).value.trim();if(map[id])$(map[id]).textContent=v||fallback(id);});
$("avatar").textContent=($("name").value.trim()[0]||"N").toUpperCase();
let contact=[$("city").value,$("email").value,$("phone").value].filter(Boolean);
$("outContact").textContent=contact.length?contact.join("  •  "):"المدينة　•　البريد الإلكتروني　•　الهاتف";
let skills=$("skills").value.split(/[,،]/).map(x=>x.trim()).filter(Boolean);
$("outSkills").innerHTML="";
(skills.length?skills:["مهارة 1","مهارة 2"]).forEach(s=>{let span=document.createElement("span");span.textContent=s;$("outSkills").appendChild(span);});
}
function fallback(id){return ({name:"اسمك الكامل",job:"المهنة المطلوبة",summary:"اكتب نبذة قصيرة لتظهر هنا...",experience:"المنصب والشركة",experienceDetails:"تفاصيل التجربة المهنية...",education:"المستوى الدراسي"})[id]||""}
ids.forEach(id=>$(id).addEventListener("input",update));
function printCV(){window.print()}
$("printTop").addEventListener("click",printCV);$("printBottom").addEventListener("click",printCV);
$("reset").addEventListener("click",()=>{$("cvForm").reset();update()});
const translations={fr:{name:"Nom complet",job:"Poste recherché",city:"Ville",email:"E-mail",phone:"Téléphone",summary:"Profil professionnel",experience:"Poste et entreprise",experienceDetails:"Détails de l’expérience",education:"Formation",skills:"Compétences (séparées par virgule)"}};
$("language").addEventListener("change",e=>{let fr=e.target.value==="fr";document.documentElement.lang=fr?"fr":"ar";document.documentElement.dir=fr?"ltr":"rtl";document.querySelectorAll("[data-ar][data-fr]").forEach(el=>el.textContent=el.dataset[fr?"fr":"ar"]);document.querySelectorAll("#cvForm label>span").forEach((el,i)=>{let key=ids[i];if(translations.fr[key])el.textContent=fr?translations.fr[key]:["الاسم الكامل","المهنة المطلوبة","المدينة","البريد الإلكتروني","الهاتف","نبذة قصيرة عنك","المنصب والشركة","تفاصيل التجربة","المستوى الدراسي","المهارات (افصل بينها بفاصلة)"][i]});});
update();